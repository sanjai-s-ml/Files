import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        try {
            BufferedWriter fi = new BufferedWriter(new FileWriter("sample.txt",true));

            fi.newLine();
            fi.write("From my end");
            fi.flush();
            fi.close();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}