import java.sql.*;
import java.util.Scanner;

public class DML {
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        Class.forName("org.sqlite.JDBC");
        Connection con=DriverManager.getConnection("jdbc:sqlite://home//Sanjai//Documents//univ.db");
        //Statement stm=con.createStatement();
        //stm.executeUpdate("insert into dept values(60,'Chem')");
        //stm.executeUpdate("insert into dept values(70,'Phy')");
        //stm.executeUpdate("delete from dept where deptno > 60");
        //stm.executeUpdate("update dept set dname='Chemical' where deptno=60");
        PreparedStatement pstm=con.prepareStatement("insert into students values(?,?,?,?)");
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter values :");
        int roll=sc.nextInt();
        String name=sc.next();
        String city=sc.next();
        int deptno=sc.nextInt();
        pstm.setInt(1,roll);
        pstm.setString(2,name);
        pstm.setString(3,city);
        pstm.setInt(4,deptno);
        pstm.executeUpdate();
        pstm.close();
        con.close();
    }
}
