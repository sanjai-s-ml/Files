import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;

public class Files {
    public static void main(String[] args) throws IOException {
        File file=new File("news.txt");
        if(file.createNewFile()){
            System.out.println("File created successfully");
        }
        else{
            System.out.println("File already exists");
        }
        System.out.println("Is file " +file.isFile());
        System.out.println(" Name "+ file.getName());
        System.out.println("Absolute path "+ file.getAbsolutePath());
        System.out.println("size "+file.length());
    }
}
