import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;

public class pathClass {
    public static void main(String[] args) {
        try(FileOutputStream fos=new FileOutputStream("news.txt",true);
            FileInputStream fis=new FileInputStream("news.txt")){
            String data="Java ";
            fos.write(data.getBytes());

            byte[] buffer=new byte[1024];
            int bytesRead=fis.read(buffer);
            System.out.println(new String(buffer));
            System.out.println("Read "+ new String(buffer,0,bytesRead));
        }
        catch (IOException e){
            e.printStackTrace();
        }

    }
}
