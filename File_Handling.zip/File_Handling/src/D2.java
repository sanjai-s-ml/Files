import java.sql.*;
import java.util.Scanner;

public class D2 {
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
            Class.forName("org.sqlite.JDBC");
        Connection con=DriverManager.getConnection("jdbc:sqlite://home//Sanjai//Documents//univ.db");
        PreparedStatement stm=con.prepareStatement("select * from students where deptno=?");
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter dept no");
        int deptno=sc.nextInt();
        stm.setInt(1,deptno);
        ResultSet rs=stm.executeQuery();
        while(rs.next()){
            System.out.print("Roll No : "+ rs.getInt("roll")+" ");
            System.out.print("Name : "+ rs.getString("name")+" ");
            System.out.print("City : "+ rs.getString("city")+" ");
            System.out.println("dept : "+ rs.getInt(4)+" ");
        }
        stm.close();
        con.close();
    }
}
