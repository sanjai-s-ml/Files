import java.io.FileWriter;

public class FileWriterC {
    public static void main(String[] args) {
        try{
            FileWriter fw=new FileWriter("new.txt");
            fw.write("Hi everyone here ndsjnvsdnv");
            fw.close();
        }
        catch (Exception e){
            System.out.println(e.getCause());
        }
    }
}
