package com.example;

import  java.util.*;
import javax.persistence.*;
@Entity
@Table(name="orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long id;

    @Column(name="order_date")
    private Date orderDate;
    @Column(name="amount")
    private Double amount;

    public Order(){}
    public Order(Date orderDate,Double amount){
        this.amount=amount;
        this.orderDate=orderDate;
    }
    public Long getId(){
        return this.id;
    }
    public void setId(Long id){
        this.id=id;
    }

    public Date getOrderDate(){
        return this.orderDate;
    }
    public void setOrderDate(Date orderDate){
        this.orderDate=orderDate;
    }

    public Double getAmount(){
        return this.amount;
    }
    public void setAmount(Double amount){
        this.amount=amount;
    }

    @ManyToOne
    @JoinColumn(name ="customer_id")
    private Customer customer;

    public Customer getCustomer(){
        return this.customer;
    }

    public void setCustomer(Customer customer){
        this.customer=customer;
    }
}
