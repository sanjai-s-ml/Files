package com.example;
import javax.persistence.*;
import java.util.*;
@Entity
@Table(name="customers")
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long id;
    @Column(name= "name")
    private String name;
    @Column(name= "email")
    private String email;

    Customer(){
    }
    Customer(String name,String email){
        this.name=name;
        this.email=email;
    }

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    @OneToMany(mappedBy = "customer",cascade = CascadeType.ALL)
    private List<Order> orders=new ArrayList<>();

    public List<Order> getOrders(){
        return this.orders;
    }

    public void setOrders(List<Order> orders){
        this.orders=orders;
    }
    //method to add orders
    public void addOrders(Order order){
       this.orders.add(order);
       order.setCustomer(this);
    }
}
