package com.example;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.*;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
    SessionFactory sessionFactory=new Configuration().configure("hibernate.cfg.xml")
            .addAnnotatedClass(Customer.class).addAnnotatedClass(Order.class).buildSessionFactory();
    Session session=null;
    Transaction transaction=null;

    try{
        session=sessionFactory.openSession();
        transaction=session.beginTransaction();

        //create
//        Customer customer=new Customer("Sanjai","sanjai@gmail.com");
//        session.save(customer);
//        transaction.commit();
//        System.out.println("Customer inserted Successfully");

        //Read using session.get() -> it goes to db and fetches it.if not found retuen null
//        Customer customer=session.get(Customer.class,3L);
//        if(customer!=null){
//            System.out.println("Name : "+ customer.getName()+" "+ " Email : "+customer.getEmail());
//        }
//        else{
//            System.out.println("Customer not found");
//        }

        //Read using session.load() -> it goes to proxy. it runs only when we try to use the object method of that class ,if not found gives ObjectNotFoundException.
//        Customer customer=session.load(Customer.class,3L);
//        System.out.println("Found Customer :"+customer.getName());
//        //read more than one object . there where we use HQL. session.createQuery()
//        String hql="from Customer";// Customer is class Name- > we are using it with HQL (Objec-oriented query language) that means it works with Java class , methods and objects
//        List<Customer> customer=session.createQuery(hql,Customer.class).getResultList();
//        for(Customer c:customer){
//            System.out.println("Id : "+c.getId()+" "+"Name : "+c.getName()+" "+"Email : "+c.getEmail());

        //Update query
        //step-1 retrieve
        //step-2 modify the object properties
        //step-3 Persisit the changes
//        Customer customer=session.get(Customer.class,2L);
//        if(customer!=null){
//            customer.setName("satvik");
//            customer.setEmail("satvik@gmail.com");
//            session.update(customer);
//            transaction.commit();
//            System.out.println("Updated Successfully");
//      }
//        else{
//            System.out.println("Customer details not found");
//        }

        //Delete
        //Step-1 : Retrieve the data
        //Step-2 : delete using session.delete()
//        Customer customer=session.get(Customer.class,1L);
//        if(customer!=null){
//            session.delete(customer);
//            transaction.commit();
//            System.out.println("Customer details deleetd from DB");
//        }
//        else{
//            System.out.println("Customer details not found ");
//        }

//        //OneToMany create
//        Customer customer=new Customer("John Doe","John.Doe@gmail.com");
//        Order order=new Order(new Date(),250.50);
//        customer.addOrders(order);
//        session.save(customer);
//        transaction.commit();
//        System.out.println("Customer and Order Saved Successfully");

        //OneToMany Read
//        Customer customer=session.get(Customer.class,4L);
//        if(customer!=null){
//            System.out.println("Customer Found : "+customer.getName()+ " "+ " Email : "+customer.getEmail());
//            System.out.println("Order Details : ");
//            for(Order o:customer.getOrders()){
//                System.out.println("Order Id "+o.getId()+" "+"Order Date : "+o.getOrderDate()+" "+"Order Amount : "+o.getAmount()+" "+"Customer Id : "+o.getCustomer().getId());
//            }
//        }
//        else{
//            System.out.println("Customer not Found");
//        }
//        transaction.commit();

        //Update OneToMany
//        Customer customerToUpdate=session.get(Customer.class,4L);
//        if(customerToUpdate!=null && !customerToUpdate.getOrders().isEmpty()){
//            customerToUpdate.setEmail("jane@gmail.com");
//            Order orderToUpdate=customerToUpdate.getOrders().get(0);
//            orderToUpdate.setAmount(500.50);
//            session.update(orderToUpdate);// we have used cascade so if we update one remaining all will be updated automatically
//        }
//        transaction.commit();
//        System.out.println("Order Saved Successully");

        //Delete OneToMany
//        Customer customer=session.get(Customer.class,5L);
//        if(customer!=null){
//            session.delete(customer);//Same CascadeType.ALL property
//            System.out.println("Customer and all related methods deleted successfully");
//        }
//        else{
//            System.out.println("Customer not found");
//        }
//        transaction.commit();
    }
    catch(Exception e){
        if(transaction!=null){
            transaction.rollback();
        }
        e.printStackTrace();
    }
    finally {
        if(session!=null){
            session.close();
        }
        sessionFactory.close();
    }
    }
}