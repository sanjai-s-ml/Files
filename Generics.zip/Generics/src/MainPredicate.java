//Return boolean based output
interface MyBoolean<T>{//Predicate
    boolean isValid(T input);

}
public class MainPredicate {
    public static void main(String[] args) {
        MyBoolean<String> str=(st) -> st.length()>=5;
        System.out.println(str.isValid("Sanjai"));
    }
}
