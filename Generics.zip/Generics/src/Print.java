public class Print <T>{
    T val;

    public void setVal(T obj){
        this.val=obj;
    }

    public T getVal(){
        return this.val;
    }
}
