interface MyPrinter<T>{
    void print(T input); // consumer - Takes input and returns nothing
}
public class MainConsumer {
    public static void main(String[] args) {
        MyPrinter<String> printer =name -> System.out.println(name);
        printer.print("SANJAI");
    }
}
