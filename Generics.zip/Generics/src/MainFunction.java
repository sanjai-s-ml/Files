//converts input T to output R
interface MyTransform<T,R>{ // Function<T,R>
    R transform(T input);
}

public class MainFunction {
    public static void main(String[] args) {
        MyTransform<String , Integer> str= (String st) -> Integer.parseInt(st);
        System.out.println(str.transform("12"));
    }
}
