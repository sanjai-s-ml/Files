public class Main2 extends Print<String>{
    public static void main(String[] args) {
        Print<String> str=new Print<String>();
        str.setVal("SANJAI");
        System.out.println(str.getVal());
    }
    //normal subclass
}
