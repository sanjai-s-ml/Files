public class Gsubclass  {
    public static void main(String[] args) {
        subclass<Float> bl=new subclass<Float>();
        bl.setVal(1507.2004F);
        System.out.println(bl.getVal());
    }
}

class subclass <T> extends Print<T>{
// generic subclass
}
