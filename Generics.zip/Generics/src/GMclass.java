import java.util.ArrayList;
import java.util.List;

public class GMclass extends GM{
    public static void main(String[] args) {
        GM gm=new GM();
        List<? super Number> li=new ArrayList<>();
        List<Integer> li2=new ArrayList<>();
        li.add(20);
        li.add(30);
        gm.setVal(li,li2);

    }
}
//generic methode
class GM{

    public  void setVal(List<? super Number> value,List<? extends Number> value2){
        System.out.println(value);
    }
}
