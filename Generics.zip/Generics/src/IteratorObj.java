import java.util.*;
public class IteratorObj {
 public static void main(String[] args){
     List<Integer> li=new ArrayList<>();
     li.add(20);
     li.add(57);
     li.add(49);
     li.add(78);
     li.forEach((Integer val)->System.out.println(val));
 }
}
