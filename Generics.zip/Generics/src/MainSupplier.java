import java.util.UUID;

interface MyGenerator<T>{
    T generate();// supplier takes no input but produces output
}
public class MainSupplier {
    public static void main(String[] args) {
        MyGenerator<String> num=() -> UUID.randomUUID().toString().substring(0,8);
        System.out.println(num.generate());
    }
}
