# required libraries
import os

import argparse
from ats import aetest
from lib.models.policies.access_control.access_control.access_policy.model import AccessPolicy
import lib.standard_testcase.common.common_setup as stlCommon
from tests.system.utils.topology.topology_manager import TopologyManager
from lib.services.data.store import store
import lib.standard_testcase.policies.access_control.access_policy.policy_assignments as device_lib
from tests.feature.systems.utils.testbed import Testbed
import lib.standard_testcase.devices.device_management.deploy as deploy_lib
import lib.standard_testcase.common.common_cleanup as common_cleanup_lib




parser = argparse.ArgumentParser(description="standalone parser")
parser.add_argument('--testbed', dest='testbed', default=None, help='Testbed YAML file path')
DATA_PATH = 'data/kt-policy.yaml' # file path
base_dir = os.path.dirname(__file__) # current directory path
args = parser.parse_known_args()[0] # to pass arguments  ( Example : python3 kt-policy.py --name 'sanjai' --age 21 )
path = ("{}/{}".format(base_dir, DATA_PATH)) # here merging above 2 and getting the exact path


# path = "tests/feature/ftd/tests/EVE/data/kt-policy.yaml"
#three steps
#common setup
#test case
#cleanup

class CommonSetup(stlCommon.CommonSetupSTL):

    @aetest.subsection # only for common setup
    def config_initialize(self, topology_manager: TopologyManager, testbed): #commonsetup intialization file

        self.parent.parameters.update(
            {
                "ac_policy_config": store.get("file:{}".format(path), # getting the details from yaml file and storing it in ac_policy_config
                                    root_object='access_policies.kt_ac_policy'), # informing the file to access access_policies.lt_ac_policy in yaml file , 
                                                                                 # acc_policies we get it from yaml factory, root_object = to inform which policy we are specifically acessing from yaml file ,
                                                                                 # if we have multiple policies instead of creating seperate variable we can just use root_object and call which ever needed at that time 
            }
        )



class CreateACPolicyTwoRule(aetest.Testcase): # testcase , it will be automatically called bcz we have given as aetest.Testcase
 
    @aetest.test
    def init_params(self, topology_manager):
        self.fmc_api_service = topology_manager.active_fmc.api_service # initializing for policy creation
 
    @aetest.test
    def create_acp(self, ac_policy_config: AccessPolicy): # informing to create Ac policy ... defining which policy it should create that is AccessPolicy
        self.fmc_api_service.create(ac_policy_config) # passing the variable which contains the details of the yaml file


    
class AssignACPolicyTwoRule(device_lib.AssignACPolicy): # assigning to ftd

    @aetest.test # decoraters are must to tell it is a pyATS code
    def init_params(self, testbed: Testbed, topology_manager: TopologyManager, ac_policy_config):
        self.ac_policy_name = ac_policy_config.name # sample-Ac-policy is stored here
        self.ftd_devices = topology_manager.ftd_list[0].name # storing the changes in the first ftd (sensor) (as it is stored in list using index we are accessing it)



class Deploy_ACPolicyTwoRule(deploy_lib.DeployOnDeployableDevices):
    pass
    # for deployment
 


# clean up class
class CommonCleanup(common_cleanup_lib.CommonCleanupSyslib):
    pass
 

########################################################################################################################
if __name__ == '__main__':
    aetest.main()
########################################################################################################################