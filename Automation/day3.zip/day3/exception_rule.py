import inspect
import logging
from pyats import aetest
from lib.standard_testcase.common import TestcaseSTL
from lib.models.objects.network.network_object.model import NetworkObject
from lib.models.objects.security_intelligence.eve_exception_list.model import EveExceptionRuleList

log = logging.getLogger(__name__)
log.setLevel(logging.DEBUG)

# flow comes here bcz we have inherited this class
class CreateEveExceptionSTL(TestcaseSTL):
    groups = ['eve_exception']

    process_entry: bool = False # it is to inform that we are creating a exception rule of with following fields like processName, destinationNetwork, etc..
    dest_network_entry: bool = False # set this to true if we are using this 
    source_network_entry: bool = False
    dynattr_entry: bool = False
    payload_config = None
    new_entry = {} # to store the payload
# after variables are assigned
    def __init__(self, *args, **kwargs): # calls when inherited
        super().__init__(*args, **kwargs)
        self.params_to_validate.extend(["_fmc_api_service", "payload_config"])
        self._fmc_api_service = self.parameters.get('topology_manager').active_fmc.api_service
        self.process_entry = self.parameters.get('process_entry', self.process_entry)
        self.dest_network_entry = self.parameters.get('dest_network_entry', self.dest_network_entry)
        self.source_network_entry = self.parameters.get('source_network_entry', self.source_network_entry)
        self.dynattr_entry = self.parameters.get('dynattr_entry', self.dynattr_entry)
        self.payload_config = self.parameters.get('payload_config', self.payload_config)
#this function is called
    @aetest.test
    def create_exception_rule(self):
        try:
            exceptionrule = self._fmc_api_service.find_all( # to create a ExceptionRule frontend and backend teams has an id of EveExceptionRule with that only we can create an EveExceptionRule.
                EveExceptionRuleList()) #(it is FTL class) to get that id just call EveExceptionRuleList() with empty arguments, it will give us all the objects bcz using find_all. It returns a list of objects.
            eveObjectId = exceptionrule[0].id # from the list of objects by index we getting the id
            exceptionrule_object = EveExceptionRuleList() # again creating object with the default values
            exceptionrule_object.identifier = eveObjectId # identifier is like id only it is present in Model file inherited in FTL, as said with existing EveExceptionRuleList only we can create new EveExceptionRuleList
            exceptionrule_object.id = eveObjectId # we are setting the id which we have fetched from the list of objects
            new_exceptionrule_object = self._fmc_api_service.find_one_by_record(exceptionrule_object) #finds and gives us the exceptionrule
            if self.process_entry: # checks if process_entry is true , then updating the payload
                self.new_entry.update({
                    "processNames": self.payload_config['processNames'], # fetching and storing it from the payload_config
                    "comment": self.payload_config['comment']
                })
            if self.dest_network_entry:
                self.new_entry.update({
                    "destinationNetworks": {
                        "objects": [
                            {
                                "id": self.payload_config['dest_id'],
                                "type": self.payload_config['dest_type'],
                                "name": self.payload_config['dest_name']
                            }]}})
            if self.source_network_entry:
                self.new_entry.update({
                    "sourceNetworks": {
                        "objects": [
                            {
                                "id": self.payload_config['src_id'],
                                "type": self.payload_config['src_type'],
                                "name": self.payload_config['src_name']
                            }]}})

            if self.dynattr_entry:
                self.new_entry.update({
                    "dynamicAttributes": {
                        "objects": [
                            {
                                "id": self.payload_config['dyn_id'],
                                "type": self.payload_config['dyn_type'],
                                "name": self.payload_config['dyn_name']
                            }]}
                })
            new_exceptionrule_object.entries.append(self.new_entry) # entries is present in FTL storing it in FTL , ie., EveExceptionRuleList
            ret_val = self._fmc_api_service.update(new_exceptionrule_object) # there is no post , only update and delete. updating it in the api , creating exception rule here
            self.new_entry.clear()

        except Exception:
            new_message = 'Error occurred while creating the Exception rule'
            self._error_message = self.concat_error_message(new_message)
            log.exception(new_message)
            self._cim_comment_text[inspect.stack()[0][3]] = self._error_message
            self.failed(self._error_message, goto=[self.failure_handling])

# when update class is inherited flow comes here after init_params is called in kt-policy.py file
class UpdateEveExceptionSTL(TestcaseSTL):
    groups = ['eve_exception']
    rule_type: str = None
    process_name: str = None
    network_config: dict = {}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.params_to_validate.extend(["_fmc_api_service", "rule_type"])
        self._fmc_api_service = self.parameters.get('topology_manager').active_fmc.api_service
        self.rule_type = self.parameters.get('rule_type', self.rule_type)
        self.process_name = self.parameters.get('process_name')
        self.object_name = self.parameters.get('object_name')
        self.network_config = self.parameters.get('network_config', self.network_config)

    @aetest.test
    def update_exception_rule(self):
        try:
            exceptionrule = self._fmc_api_service.find_all(EveExceptionRuleList())
            eveObjectId = exceptionrule[0].id
            exceptionrule_object = EveExceptionRuleList()
            exceptionrule_object.identifier = eveObjectId
            exceptionrule_object.id = eveObjectId

            # updating process_name
            if self.process_name and self.rule_type == 'processNames':
                new_exceptionrule_object = self._fmc_api_service.find_one_by_record(exceptionrule_object)
                new_exceptionrule_object.entries[0].processNames = [self.process_name]
                self._fmc_api_service.update(new_exceptionrule_object)

            # updating  destination network/ source network/ fqdn object
            if self.network_config and self.rule_type == 'Networks':
                network_object = self._fmc_api_service.find_one(NetworkObject,
                                                                lambda network: network.name == self.object_name)
                if 'name' in self.network_config:
                    network_object.name = self.network_config['name']
                if 'type' in self.network_config:
                    network_object.type = self.network_config['type']
                if 'value' in self.network_config:
                    network_object.value = self.network_config['value']
                if 'dnsResolution' in self.network_config:
                    network_object.dnsResolution = self.network_config['dnsResolution']
                self._fmc_api_service.update(network_object)

        except Exception:
            new_message = 'Error occurred while updating the Exception rule'
            self._error_message = self.concat_error_message(new_message)
            log.exception(new_message)
            self._cim_comment_text[inspect.stack()[0][3]] = self._error_message
            self.failed(self._error_message, goto=[self.failure_handling])


class DeleteEveExceptionSTL(TestcaseSTL):
    groups = ['eve_exception']
    delete_all: bool = False
    index: int = None

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.params_to_validate.extend(["_fmc_api_service"])
        self._fmc_api_service = self.parameters.get('topology_manager').active_fmc.api_service
        self.delete_all = self.parameters.get('delete_all', self.delete_all)
        self.index = self.parameters.get('index', self.index)

    @aetest.test
    def delete_exception_rule(self):
        try:
            exceptionrule = self._fmc_api_service.find_all(EveExceptionRuleList())
            eveObjectId = exceptionrule[0].id
            exceptionrule_object = EveExceptionRuleList()
            exceptionrule_object.identifier = eveObjectId
            exceptionrule_object.id = eveObjectId

            new_exceptionrule_object = self._fmc_api_service.find_one_by_record(exceptionrule_object)
            if self.delete_all:  # clear all the rules
                new_exceptionrule_object.entries.clear()
            elif self.index is not None:  # remove at specific index
                new_exceptionrule_object.entries.pop(self.index)
            else:
                new_exceptionrule_object.entries.pop()  # remove the last entry
            self._fmc_api_service.update(new_exceptionrule_object)

        except Exception:
            new_message = 'Error occurred while deleting the Exception rule'
            self._error_message = self.concat_error_message(new_message)
            log.exception(new_message)
            self._cim_comment_text[inspect.stack()[0][3]] = self._error_message
            self.failed(self._error_message, goto=[self.failure_handling])