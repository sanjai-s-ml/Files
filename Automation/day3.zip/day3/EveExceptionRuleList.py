class EveExceptionRuleList(Model): # this is FTL file
    _available_apis = {
        AvailableAPIS.rest.value: {
            APIDefinition.adapter: RestAdapter(),
            APIDefinition.serializer: BaseRestSerializer(),
            APIDefinition.deserializer: BaseModelDeserializer(),
            APIDefinition.identifier_field: IdentifierFields.id_identifier.value
        }
    }
    
    _default_api = AvailableAPIS.rest.value
    
    type="EVEEXCEPTIONLIST"
    name=None
    entries=HasMany('entries', ExceptionRuleFragment) 
    
    def __init__(self, **kwargs):
        self.update_dict(kwargs, self._available_apis, self._default_api)
        super().__init__(**kwargs)
        self.name=kwargs.get('name', None)
        self.entries=kwargs.get('entries', [])
        
        
class EveExceptionRuleListFactory(BaseFactory):
    class Meta:
        model= EveExceptionRuleList