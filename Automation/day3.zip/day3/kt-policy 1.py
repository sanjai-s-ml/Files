# required libraries
import os

import argparse
from ats import aetest
from lib.models.policies.access_control.access_control.access_policy.model import AccessPolicy
import lib.standard_testcase.common.common_setup as stlCommon
from tests.system.utils.topology.topology_manager import TopologyManager
from lib.services.data.store import store
import lib.standard_testcase.policies.access_control.access_policy.policy_assignments as device_lib
from tests.feature.systems.utils.testbed import Testbed
import lib.standard_testcase.devices.device_management.deploy as deploy_lib
import lib.standard_testcase.common.common_cleanup as common_cleanup_lib
from lib.standard_testcase.policies.access_control.access_policy.eve import EVESettingSTL
from lib.standard_testcase.objects.security_intelligence.eve_exception_lists.exception_rule import \
CreateEveExceptionSTL, UpdateEveExceptionSTL , DeleteEveExceptionSTL



parser = argparse.ArgumentParser(description="standalone parser")
parser.add_argument('--testbed', dest='testbed', default=None, help='Testbed YAML file path') # --testbed if we give it and enter some values then it will be stored in the variable declared in dest i.e testbed
#if we give python3 file.py --testbed value_value it will be stored in testbed (i.e. dest=testbed)
DATA_PATH = 'data/kt-policy.yaml' # file path
base_dir = os.path.dirname(__file__) # current directory path
args = parser.parse_known_args()[0] # to pass arguments  ( Example : python3 kt-policy.py --name 'sanjai' --age 21 )
path = ("{}/{}".format(base_dir, DATA_PATH)) # here merging above 2 and getting the exact path


# path = "tests/feature/ftd/tests/EVE/data/kt-policy.yaml"
#three steps
#common setup
#test case
#cleanup

class CommonSetup(stlCommon.CommonSetupSTL):

    @aetest.subsection # only for common setup
    def config_initialize(self, topology_manager: TopologyManager, testbed): #commonsetup intialization file , 
        # TopologyManager is to fetch the "topology" details from testbed file .
        # whenever we are using TopologyManager in function we will also use testbed. testbed.py and topology_manager.py are seperate files .
        # In topology_manager.py file, it's work is to fetch the details of fmc, ftd, endpoint from testbed file and store it in it's list. it initializes 3 list intially like fmc_list[] , ftd_list[] , endpoint_list[]
        # In testbed.py file, it's work is to fetch all the all the variables, keyword , values from testbed yaml file and store it in testbed.py file. we are passing testbed here to access it.
        
        fmc1 = topology_manager.fmc_list[0].config_provider # like this we can access the fmc1 details using topology_manager , it is stored in list so using index to access it. 
        fmc_ssh = topology_manager.fmc_list[0].config_provider.ssh_connection # There will be 1 FMC , 2 FTD , 2 Endpoints
        ftd1_ssh = topology_manager.ftd_list[0].config_provider.ssh_connection # what is this config_provider ? where it is present.
        ftd2_ssh = topology_manager.ftd_list[1].config_provider.ssh_connection
        sensor1_ip = topology_manager.ftd_list[0].ip
        sensor2_ip = topology_manager.ftd_list[1].ip
        ep1_ssh = topology_manager.endpoint_list[0].config_provider.ssh_connection
        ep2_ssh = topology_manager.endpoint_list[1].config_provider.ssh_connection

        self.parent.parameters.update(
            # here in STL everything is class , to access the variable of another class  we need to create object of the respective class each time . It is difficult.
            # So if we declare and define the variables in self.parent.parameters.update() we can just use them directly without creating objects each time.
            {
                "ac_policy_config": store.get("file:{}".format(path), # getting the details from yaml file and storing it in ac_policy_config
                                    root_object='access_policies.kt_ac_policy'), # informing the file to access access_policies.lt_ac_policy in yaml file , 
                                                                                # acc_policies we get it from yaml factory, root_object = to inform which policy we are specifically acessing from yaml file ,
                                                                                 # if we have multiple policies instead of creating seperate variable we can just use root_object and call which ever needed at that time 
                "eve_setting_config": store.get("file:{}".format(path),
                                    root_object='eve_setting.enable_combination_with_Very_high_protected'), # sharing the eve enable setting details to eve_setting_config

                "process_name_config": store.get("file:{}".format(path),
                                    root_object='exception_rule_list.first_rule'), # fetching the details of exception rule creation from yaml file


                                    
                "fmc1": fmc1,
                "fmc_ssh": fmc_ssh,
                "ftd1_ssh": ftd1_ssh,
                "ftd2_ssh": ftd2_ssh,
                "sensor1_ip": sensor1_ip,
                "sensor2_ip": sensor2_ip,
                "ep1_ssh": ep1_ssh,
                "ep2_ssh": ep2_ssh
            }
        )


#creating access policy
class CreateACPolicyTwoRule(aetest.Testcase): # testcase , it will be automatically called bcz we have given as aetest.Testcase
 
    @aetest.test
    def init_params(self, topology_manager):
        self.fmc_api_service = topology_manager.active_fmc.api_service # initializing for policy creation
 
    @aetest.test
    def create_acp(self, ac_policy_config: AccessPolicy): # informing to create Ac policy ... defining which policy it should create that is AccessPolicy
        self.fmc_api_service.create(ac_policy_config) # passing the variable which contains the details of the yaml file


    
class AssignACPolicyTwoRule(device_lib.AssignACPolicy): # assigning to ftd

    @aetest.test # decoraters are must to tell it is a pyATS code
    def init_params(self, testbed: Testbed, topology_manager: TopologyManager, ac_policy_config):# TopologyManager class, topology_manager is object , creating object directly here
        self.ac_policy_name = ac_policy_config.name # sample-Ac-policy is stored here
        self.ftd_devices = topology_manager.ftd_list[0].name # storing the changes in the first ftd (sensor) (as it is stored in list using index we are accessing it)


class Update_EVE_WITH_VERY_HIGH_PROTECTED_Block(EVESettingSTL):
# STL is just for intialization. init_params is automatically called bcz of @aetest.test.
#The values are fetched from yaml and stored it in the variables .

    @aetest.test
    def init_params(self, ac_policy_eve2_config, eve_setting_config): #eve_setting_config 
        self.access_policy_name = ac_policy_eve2_config.name # mandatory , if not given it gives error . if the mode, enabled , blockThreshold are not given it does not give error , eve may be enabled or not .
        self.mode = eve_setting_config.mode
        self.enabled = eve_setting_config.enabled
        self.blockThreshold = eve_setting_config.blockThreshold
# After assigning the values it calls EVESettingSTL (eve.py)


class createExceptionRuleList(CreateEveExceptionSTL): #it is used to create exception rule list
    # as we have inherited the class, the variables will be set in the CreateEveExceptionSTL class in exception_rule.py file
    combined_rule_config={} # empty dict to store payload
    
    
    def create_process_name(self, process_name_config):
        self.combined_rule_config.update({ # creating payload here
            "processNames": process_name_config.processNames,
            "comment": process_name_config.comment
        })
        
    @aetest.test
    def init_params(self, topology_manager ,process_name_config ):
        self._fmc_api_service=topology_manager.active_fmc_api_service # api service it is mandatory, it is a class which handles API requests
        self.process_entry= True # setting that processName is being created
        self.create_process_name(process_name_config) # this method creates the payload
        self.payload_config=self.combined_rule_config # payload is mandatory
    #flow goes to exception_rule.py
class updateExceptionRuleList(UpdateEveExceptionSTL): # it is used to update the exception rule list
    
    @aetest.test
    def init_params(self,topology_manager,process_name_config):
        self._fmc_api_service=topology_manager.active_fmc_api_service
        self.process_name=process_name_config.processNames[0]
        self.rule_type="processNames"
        

class deleteExceptionRuleList(DeleteEveExceptionSTL): # it is used to delete the exception rule list
    @aetest.test
    def init_params(self,topology_manager,process_name_config):
        self._fmc_api_service=topology_manager.active_fmc_api_service
        #self.index=1 # this index is from processName of yaml file
        self.delete_all=True

class Deploy_ACPolicyTwoRule(deploy_lib.DeployOnDeployableDevices):
    pass 
    # for deployment
 
# to do ssh between FTD and Endpoint
class Running_clear_snort_Commands_very_high_protected(aetest.Testcase):
 # it is automatically called because of @aetest.test decorator
    @aetest.test
    def run_ftd_commands(self, ftd1_ssh):
        ftd1_ssh.conn.go_to('fireos_state') # this command is to go to fireos state[default]. 
        #There will be 2 states expert and fireos . expert mode for viewing files. 
        #fireos mode is for running commands.
        ftd1_ssh.conn.execute("clear snort counters")
        ftd1_ssh.conn.execute("clear conn")


# clean up class
class CommonCleanup(common_cleanup_lib.CommonCleanupSyslib):
    pass
 

########################################################################################################################
if __name__ == '__main__':
    aetest.main()
########################################################################################################################