from lib.constants import AvailableAPIS, APIDefinition
from lib.models.fragments.fragment import Fragment
from lib.models.fragments.rules.networks.model import RuleNetworksFragment
from lib.models.objects.dynamic_object_exceptionrule.model import DynamicObjectFragment
from lib.models.objects.dynamic_objects.model import DynamicObject
from lib.services.data.attributes.has_one import HasOne
from lib.services.data.base_deserializer import BaseModelDeserializer
from lib.services.data.base_factory import BaseFactory
from lib.api.rest.base_rest_serializer import BaseRestSerializer


class ExceptionRuleFragment(Fragment): # FTL file
    _available_apis = {
        AvailableAPIS.rest.value: {
            APIDefinition.serializer: BaseRestSerializer(),
            APIDefinition.deserializer: BaseModelDeserializer()
        }
    }
    _default_api = AvailableAPIS.rest.value

    #:  ExceptionRule Rule List Destination Networks
    destinationNetworks = HasOne('destinationNetworks', RuleNetworksFragment)
    #:  ExceptionRule Rule List source Networks
    sourceNetworks = HasOne('sourceNetworks', RuleNetworksFragment)
    #: comment EveExceptionRule rule comments
    comment = None
    #: processNames EveExceptionRule process names
    processNames = []
    #: ExceptionRule Rule List Dynamic Objects
    dynamicAttributes = HasOne('dynamicAttributes', DynamicObjectFragment)

    def __init__(self, **kwargs):
        self.update_dict(kwargs, self._available_apis, self._default_api)
        super().__init__(**kwargs)
        self.destinationNetworks = kwargs.get('destinationNetworks', None) 
        self.sourceNetworks = kwargs.get('sourceNetworks', None)
        self.comment = kwargs.get('comment', None)
        self.processNames = kwargs.get('processNames', [])
        self.dynamicAttributes = kwargs.get('dynamicAttributes', None)


class ExceptionRuleFragmentFactory(BaseFactory):
    class Meta:
        model = ExceptionRuleFragment
