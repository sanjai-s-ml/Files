from lib.api.rest.rest_adapter import RestAdapter
from lib.constants import AvailableAPIS, APIDefinition, IdentifierFields
from lib.services.data.base_deserializer import BaseModelDeserializer
from lib.services.data.base_factory import BaseFactory
from lib.api.rest.base_rest_serializer import BaseRestSerializer
from lib.models.model import Model

#EVESettings is present in yaml factory file.
#The cursor or FLOW comes here from the eve.py file after creating the EVESetting instance in eve.py file
class EVESetting(Model):
    _available_apis = {
        AvailableAPIS.rest.value: {
            APIDefinition.adapter: RestAdapter(), # calls restApi after values are assigned to it
            APIDefinition.serializer: BaseRestSerializer(),
            APIDefinition.deserializer: BaseModelDeserializer(),
            APIDefinition.identifier_field: IdentifierFields.id_identifier.value
        }
    }
# After the flow comes here from the eve.py file values are assigned to the respective variables.
    _default_api = AvailableAPIS.rest.value
    # we are using a common API, so that model should have name and type then only we can use adapter.
    type = 'EVESetting'
    name = None
    #: enabled settings for EVE
    enabled = None
    #: mode settings for EVE, Possible options: MONITOR_TRAFFIC, PROTECT_TRAFFIC
    mode = None
    #: blockThreshold settings for EVE, Possible options: VERY_HIGH, HIGH
    blockThreshold = None # used only when mode is PROTECT_TRAFFIC
    
# After the values are assigned to the respective variables. RestAPI is called using RestAdapter().

    def __init__(self, **kwargs): # when does this __init__ run ? when creating object in eve.py it runs
        self.update_dict(kwargs, self._available_apis, self._default_api)
        super().__init__(**kwargs)
        self.name = kwargs.get('name', None)
        self.enabled = kwargs.get('enabled', True)
        self.mode = kwargs.get('mode', 'MONITOR_TRAFFIC')
        self.blockThreshold = kwargs.get('blockThreshold', None)

    @staticmethod
    def is_contained() -> bool:
        return True


class EVESettingsFactory(BaseFactory):
    
    class Meta:
        model = EVESetting