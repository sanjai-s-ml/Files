import inspect
import logging

from numpy.testing import assert_equal
from pyats import aetest
from lib.models.policies.access_control.access_control.access_policy.model import AccessPolicy
from lib.services.api_service import APIService
from lib.standard_testcase.common import TestcaseSTL
from lib.models.policies.access_control.access_control.access_policy.eve_settings.model import EVESetting

log = logging.getLogger(__name__)
log.setLevel(logging.DEBUG)

# EVESettingSTL is written based on EVESetting - FTL
#STL just  calls init function. STL is just for initalization . 

# Cursor or FLOW comes here from  after it is assigned in init_params of Update_EVE_WITH_VERY_HIGH_PROTECTED_Block of kt-policy.py file
# Here values are assigned to the respective variables.
class EVESettingSTL(TestcaseSTL):
    """
    :param tls_fingerprint: Enable Encrypted Visibility Engine setting enabled or disabled - True or False.
    :param assign_client_applns_to_process: Use EVE for Application Detection
    :param show_tls_string_in_conn_events: EVE Enhanced Analytics
    :param block_traffic_on_eve_score: Block Traffic Based on EVE Score
    :param block_traffic_adv_mode: Advanced Mode for Block Traffic Based on EVE Score
    :param blockThreshold: Numbers 1 to 5 for simple mode, and 1 to 100 when Advanced Mode is activated
    :param inherit: The 'Inherit from base policy' flag visible when inheritance is activated.
    Possible values: 'True', 'False'
    :param access_policy_name: Access control policy name object
    :param _fmc_api_service: APIService of the active FMC
    """
    groups = ['eve']
    enabled: bool = None
    blockThreshold: str = None
    mode: str = None
    access_policy_name: str = None
    _fmc_api_service: APIService = None
# Here values are assigned to the respective variables.
# update_encrypted_visibility_engine_settings_in_access_policy() is called after assigning the values

    def __init__(self, *args, **kwargs): # run when object is created and runs when inherited
        super().__init__(*args, **kwargs)
        self.params_to_validate.extend(["_fmc_api_service", "access_policy_name"])
        self.access_policy_name = self.parameters.get('ac_policy_name', self.access_policy_name) # it is mandatory if it is not added we will get error.
        self._fmc_api_service = self.parameters.get('topology_manager').active_fmc.api_service

    @aetest.test
    def update_encrypted_visibility_engine_settings_in_access_policy(self):
        try:
            access_policy = self._fmc_api_service.find_one( # find_one is used to check wheather the access_policy_name we have given is available in FMC or NOT .
                AccessPolicy,
                condition=lambda policy: policy.name == self.access_policy_name
            )
            assert access_policy, f'Failed to find Access Policy: {self.access_policy_name}'
            eve_object = self._fmc_api_service.find_one_by_record(
                EVESetting(),
                container_id=access_policy.id
            )
            eve_setting_instance = EVESetting() # if the access_policy_name is available in FMC then we create an instance of EVESetting - FTL (model.py). Then it goes to EVESetting ( model.py file ) then values are assigned to that respective variables .
            eve_setting_instance.identifier = eve_object.id
            eve_setting_instance.id = eve_object.id
            encrypted_engine = self._fmc_api_service.find_one_by_record(
                eve_setting_instance,
                container_id=access_policy.id
            )
            encrypted_engine.enabled = self.enabled # when does this run ?
            if self.enabled: # here we are checking the eve is enabled or not .
                encrypted_engine.mode = self.mode # if enabled getting and storing the mode details and setting blockThreshold to none
                encrypted_engine.blockThreshold = None
                if self.mode == "PROTECT_TRAFFIC": # if the mode is PROTECT_TRAFFIC then blockthreshold is set.
                    encrypted_engine.blockThreshold = self.blockThreshold
            else:
                encrypted_engine.mode = None
                encrypted_engine.blockThreshold = None
            self._fmc_api_service.update(encrypted_engine, container_id=access_policy.id)
        except Exception as e:
            error_message = f'Failed to update encrypted visibility engine settings in AC Policy ' \
                            f'{self.access_policy_name}'
            log.exception(error_message)
            self._cim_comment_text[inspect.stack()[0][3]] = f"{error_message}: {e}"
            self.failed(error_message, goto=[self.failure_handling])

    @aetest.test
    def validate_encrypted_visibility_engine_settings(self): # this function is to check wheather the EVE settings is enabled and check the mode and blockThreshold (check blockThreshold if the mode is protected only)
        # we have set access_policy_name is mandatory , if not given it gives error . 
        # if the mode, enabled , blockThreshold are not given it does not give error , eve may be enabled or not . This is handled in this function
        try:
            access_policy = self._fmc_api_service.find_one( # similar to above one checking whether the access policy exists in the fmc or not
                AccessPolicy,
                condition=lambda policy: policy.name == self.access_policy_name
            )
            assert access_policy, f'Failed to find Access Policy: {self.access_policy_name}'

            eve_object = self._fmc_api_service.find_one_by_record(
                EVESetting(),
                container_id=access_policy.id
            )
            eve_setting_instance = EVESetting()
            eve_setting_instance.identifier = eve_object.id
            eve_setting_instance.id = eve_object.id
            encrypted_engine = self._fmc_api_service.find_one_by_record(
                eve_setting_instance,
                container_id=access_policy.id
            )
            if self.enabled is not None: # enabled in neither true nor false , enters the if
                assert_equal(encrypted_engine.enabled, self.enabled, "enabled flag was not updated correctly")

                if self.enabled and self.mode is not None: # enabled false gives AssertionError, if enabled is true and mode in not none go to next IF
                    assert_equal(encrypted_engine.mode, self.mode,
                                 "mode did not update correctly ")
                if self.mode == "PROTECT_TRAFFIC" and self.blockThreshold is not None: # if mode is protected and blockThreshold is not none goes to next step. If blockThreshold is none then it will not go to next step. is None AssertionError
                    assert_equal(encrypted_engine.blockThreshold, self.blockThreshold,
                                 "blockThreshold did not update correctly ")
        except Exception as e:
            error_message = f'encrypted visibility engine settings were not updated correctly {self.access_policy_name}'
            log.exception(error_message)
            self._cim_comment_text[inspect.stack()[0][3]] = f"{error_message}: {e}"
            self.failed(error_message, goto=[self.failure_handling])
            
