import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamClass {
    public static void main(String[] args) {
        List<Integer> list=new ArrayList<>();
        list.add(3000);
        list.add(2010);
        list.add(2010);
        list.add(10000);
        list.add(1000);
        list.add(5000);
        list.add(5000);
        List<List<String>> str=Arrays.asList(Arrays.asList("Hi","sanjai"),Arrays.asList("Welcome","To","FMC","Team"));
        Stream<Integer> result=list.stream().sorted();
        List<Integer> ans=result.collect(Collectors.toList());
        System.out.println("Result "+ result);
        System.out.println("Answer "+ ans);
        Optional<Integer> b=list.stream().findFirst();
        System.out.println("Boolean "+ b.get());
        Stream<String> sstr=str.stream().flatMap((List<String> sentence) -> sentence.stream());
        System.out.println(sstr);
        List<String> lstr=sstr.collect(Collectors.toList());
        System.out.println(lstr);
        int $a=10;
        System.out.println("a : "+$a);
    }
}
