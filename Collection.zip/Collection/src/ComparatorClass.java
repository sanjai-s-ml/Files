import java.util.*;
public class ComparatorClass {
    public static void main(String[] args) {
    List<Car> list=new ArrayList<>();
    list.add(new Car("Ford",8000,2011));
    list.add(new Car("Audi",50000,2025));
    list.add(new Car("KIA",10000,2024));
    Collections.sort(list);
        System.out.println("Based on price (Comparable)");
        list.forEach((Car car) -> System.out.println(car));
    Collections.sort(list,
            (Car c1, Car c2) -> {return c2.compareTo(c2);}
    );
        System.out.println("Based on year desc (Comparator)");
        list.forEach((Car car) -> System.out.println(car));
    }
}


class Car implements Comparable<Car> {

     String model;
     int price;
     int year;

    Car(String model,int price,int year){
        this.model=model;
        this.price=price;
        this.year=year;
    }


    public String toString(){
        return "model "+ this.model+" price "+this.price+" year "+this.year ;
    }

    @Override
    public int compareTo(Car car) {
        return this.price - car.price;
    }
}

